package com.example.priti.sentimentanalysis;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    String textInput;
    EditText TextInput;
    TextView OutputText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        OutputText=(TextView)findViewById(R.id.outputText);
        TextInput=(EditText)findViewById(R.id.textInput);
    }

    public void Submit(View view) {
        textInput = TextInput.getText().toString();


        if (textInput.equals("")) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
            alertDialogBuilder.setTitle("Buzzz....");
            alertDialogBuilder
                    .setMessage("Please Enter")
                    .setCancelable(false)
                    .setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        } else {
            String a = "{\n" +
                    "  \"Inputs\": {\n" +
                    "    \"input1\": {\n" +
                    "      \"ColumnNames\": [\n" +
                    "        \"text\"\n" +
                    "      ],\n" +
                    "      \"Values\": [[\""+textInput+"\"],[\""+textInput+"\"]\n" +
                    "      ]}},\n" +
                    "  \"GlobalParameters\": {}\n" +
                    "}";

            new ServiceFeeCall().execute(a);
        }
    }

    public class ServiceFeeCall extends AsyncTask<String, Void, String> {
        String result;
        ProgressDialog pd;
        String outputvalue;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(MainActivity.this);
            pd.setMessage("Searching for Result. Please wait...");
            pd.setIndeterminate(false);
            pd.setCancelable(false);
            pd.show();
        }
        @Override
        protected String doInBackground(String... params) {
            try {
                String Url = params[0];

                OkHttpClient client = new OkHttpClient();
                MediaType mediaType = MediaType.parse("application/json");
                RequestBody body = RequestBody.create(mediaType, Url);
                Request request = new Request.Builder()
                        .url("https://ussouthcentral.services.azureml.net/workspaces/50a521edc87c4993bebe9c9e147d0c30/services/4ef63f97a4e04f3fa9c0256e98d3e529/execute?api-version=2.0&details=true")
                        .post(body)
                        .addHeader("authorization", "Bearer i0cQUCIsUBdql5sWXwdRtVPCWP23JhGP4lfmz7INIUK0Wctycg8fej+acSpJC19y9du/NlYFrnppm3EKYzO2gg==")
                        .addHeader("content-type", "application/json")
                        .addHeader("cache-control", "no-cache")
                        .build();

                Response response = client.newCall(request).execute();
                result = response.body().string();

                return result;
            } catch (IOException e) {
                return null;
            }
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            try {
                JSONObject json = new JSONObject(result);
                JSONArray json1 = json.getJSONObject("Results").getJSONObject("output1").getJSONObject("value").getJSONArray("Values");
                for (int i = 0; i < json1.length(); i++) {
                    JSONArray json2 = json1.getJSONArray(0);
                    for (int j = 0; j < json2.length() - 1; j++) {
                        outputvalue = json2.getString(0);

                    }
                }
                OutputText.setText("Sentiment Analysis is " + outputvalue);
                if (outputvalue.equals("positive")) {
                    OutputText.setTextColor(Color.GREEN);
                } else if (outputvalue.equals("negative")) {
                    OutputText.setTextColor(Color.RED);
                } else {
                    OutputText.setTextColor(Color.BLUE);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            pd.dismiss();
        }
    }
}
